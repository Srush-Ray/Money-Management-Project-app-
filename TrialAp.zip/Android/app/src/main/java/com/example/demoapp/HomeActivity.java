package com.example.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class HomeActivity extends AppCompatActivity {
    String firstName,secondName,thirdName;
    TextView first,second,third,txt;
    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        first=(TextView)findViewById(R.id.first);
        second=(TextView)findViewById(R.id.second);
        third=(TextView)findViewById(R.id.third);
        txt=(TextView)findViewById(R.id.txt);

        new data().execute();

//        second.setText(secondName);
//        third.setText(thirdName);
//        first.setText(firstName);
//        Log.i(firstName,secondName);
    }

    public class data extends AsyncTask<Void,Void,Void>{
        String text,firstName,secondName,thirdName;
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Document doc= Jsoup.connect("https://www.espn.com/nfl/qbr").get();
                text=doc.text();
                Elements tbody=doc.getElementsByClass("Table__TD");
                String names=tbody.text();
                int i=0,j = 0,k = 0,l=0;
                if (names.toLowerCase().indexOf("1") > -1) {
                    i=names.indexOf("1");
                }
                if (names.toLowerCase().indexOf("2") > -1) {
                    j=names.indexOf("2");
                }
                if (names.toLowerCase().indexOf("3") > -1) {
                    k=names.indexOf("3");
                }
                if (names.toLowerCase().indexOf("4") > -1) {
                    l=names.indexOf("4");
                }
                firstName= names.substring(i,j);
                secondName=names.substring(j,k);
                thirdName=names.substring(k,l);
//                Toast.makeText(HomeActivity.this,firstName+" "+secondName+" "+thirdName,Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

}