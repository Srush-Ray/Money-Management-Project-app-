package com.example.demoapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignInActivity extends AppCompatActivity {
    private TextView login;
    private EditText email,password,cpassword,lastname,firstname;
    private String emailText,passwordText,cpasswordText,lastnameText,firstnameText;
    private Button signin;
    private CheckBox tp;
    private Boolean tpB=false;
    private FirebaseAuth firebaseauth;
    private Boolean done=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        login=(TextView)findViewById(R.id.log);
        email=(EditText)findViewById(R.id.email);
        firstname=(EditText)findViewById(R.id.firstName);
        lastname=(EditText)findViewById(R.id.lastName);
        password=(EditText)findViewById(R.id.password);
        cpassword=(EditText)findViewById(R.id.confirmPassword);
        signin=(Button)findViewById(R.id.signIn);
        tp=(CheckBox)findViewById(R.id.checkBox);
        firebaseauth=FirebaseAuth.getInstance();

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firstnameText=firstname.getText().toString().trim();
                lastnameText=lastname.getText().toString().trim();
                passwordText=password.getText().toString().trim();
                cpasswordText=cpassword.getText().toString().trim();
                emailText=email.getText().toString().trim();
                tpB=tp.isChecked();
                if(TextUtils.isEmpty(firstnameText)){
                    firstname.setError("Enter FirstName");
                    firstname.requestFocus();
                }
                else if(TextUtils.isEmpty(lastnameText)){
                    lastname.setError("Enter LastName");
                    lastname.requestFocus();
                }
                else if(TextUtils.isEmpty(emailText) && android.util.Patterns.EMAIL_ADDRESS.matcher(emailText).matches()){
                    email.setError("Enter Email Properly");
                    email.requestFocus();
                }else if(TextUtils.isEmpty(passwordText)){
                    password.setError("Enter Password");
                    password.requestFocus();
                }else if(TextUtils.isEmpty(cpasswordText)){
                    cpassword.setError("Enter Confirm Password");
                    cpassword.requestFocus();
                }
                else if(!tpB){
                    Toast.makeText(SignInActivity.this,"Accept Conditions.",Toast.LENGTH_LONG).show();
                }
                if(!TextUtils.isEmpty(passwordText) &&  passwordText.length()>=8){

                }else{
                    password.setError("Enter at least \nOne Uppercase \nOne Lowercase \nOne Number \nMaximum 8 Characters");
                    password.requestFocus();
                }
                    if(passwordText.equals(cpasswordText)){
                        if(passwordText.length()>=8){
                            char ch;
                            boolean capitalFlag = false;
                            boolean lowerCaseFlag = false;
                            boolean numberFlag = false;

                            int c=0,l=0,n=0;
                            for(int i=0;i < passwordText.length();i++) {
                                ch = passwordText.charAt(i);
                                if( Character.isDigit(ch)) {
                                    n++;
                                    numberFlag = true;
                                }
                                else if (Character.isUpperCase(ch)) {
                                    c++;
                                    capitalFlag = true;
                                } else if (Character.isLowerCase(ch)) {
                                    l++;
                                    lowerCaseFlag = true;
                                }
                            }
                            if(n==0){
                                password.setError("Enter at least \nOne Uppercase \nOne Lowercase \nOne Number \nMaximum 8 Characters");
                                password.requestFocus();
                            }else if(c==0){
                                password.setError("Enter at least \nOne Uppercase \nOne Lowercase \nOne Number \nMaximum 8 Characters");
                                password.requestFocus();
                            }else if(l==0){
                                password.setError("Enter at least \nOne Uppercase \nOne Lowercase \nOne Number \nMaximum 8 Characters");
                                password.requestFocus();
                            }else{
                                firebaseauth.createUserWithEmailAndPassword(emailText, passwordText)
                                        .addOnCompleteListener(SignInActivity.this, new OnCompleteListener<AuthResult>() {
                                            @Override
                                            public void onComplete(@NonNull Task<AuthResult> task) {
                                                if (task.isSuccessful()) {
                                                    Toast.makeText(SignInActivity.this,"User Registered",Toast.LENGTH_LONG).show();
                                                    Intent intent=new Intent(SignInActivity.this,MainActivity.class);
                                                    startActivity(intent);
                                                    finish();

                                                } else {
                                                    Toast.makeText(SignInActivity.this,task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                                }

                                            }
                                        });
                            }
                        }

                    }
                    else {
                        cpassword.setError("Password Mismatch");
                        cpassword.requestFocus();
                    }
                }

        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SignInActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent in=new Intent(SignInActivity.this,MainActivity.class);
        startActivity(in);
        finish();
    }
}